library(testthat)
library(costmisc)

test_check("costmisc")
