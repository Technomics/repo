#' FlexFile enumeration tables
#'
#' A list containing nine data frames: \code{PhaseOrMilestoneEnum}, \code{ContractTypeEnum},
#' \code{AppropriationTypeEnum}, \code{ReportCycleEnum}, \code{NonrecurringOrRecurringEnum},
#' \code{StandardCategoryEnum}, \code{DetailedStandardCategoryEnum}, \code{AllocationMethodTypeEnum}, and
#' \code{CostHourTagEnum}.
#'
"flexfile_enum"
