#' quantityreport class utilities
#'
#' Functions to help with with the 'quantityreport' class type.
#'
#' @name quantityreport_class
#'
#' @param x An object to test or coerce to type 'quantityreport'.
#' @inheritParams flexfile_class
#'
NULL

#' @keywords internal
new_quantityreport <- function(x, fileinfo = NULL, data_case = "snake") {
  if (is.null(fileinfo))
    fileinfo <- fileinfo_proto()

  structure(x,
            fileinfo = fileinfo, data_case = data_case,
            data_spec = readflexfile::quantity_spec,
            class = "quantityreport")
}

#' is_quantityreport
#'
#' \code{is_quantityreport()} checks if object is of type 'quantityreport'.
#'
#' @rdname quantityreport_class
#'
#' @export
is_quantityreport <- function(x) {
  inherits(x, "quantityreport")
}

#' as_quantityreport
#'
#' \code{as_quantityreport()} creates object of type 'quantityreport' and checks it against
#' the file specification.
#'
#' @rdname quantityreport_class
#'
#' @export
as_quantityreport <- function(x, names_case = c("snake_case", "data_model"),
                              .drop_optional = TRUE, .show_check = TRUE) {
  #################################################### MODIFIED
  names_case <- names_case[1]
  file_type = "Quantity"
  table_spec <- readflexfile::quantity_spec
  table_spec_mod <- table_spec

  if (names_case == "data_model") {
    x <- x %>%
      costmisc::coerce_to_spec(table_spec) %>%
      data_model_to_snake(table_spec)
  }

  table_spec_mod$fields <- table_spec$fields %>%
    dplyr::left_join(
      dplyr::select(table_spec$tables, "table", "snake_table"),
      by = "table"
    ) %>%
    dplyr::mutate(table = .data$snake_table,
                  field = .data$snake_name)

  table_spec_mod$tables <- table_spec$tables %>%
    dplyr::mutate(table = .data$snake_table)

  check <- costmisc::check_spec(x, table_spec_mod, file_type,
                                .silent = isFALSE(.show_check),
                                .include_table_type = "submission")

  # add missing tables and columns and create quantityreport object
  x <- x %>%
    costmisc::add_missing_spec_tables(table_spec_mod, check) %>%
    costmisc::add_missing_spec_cols(table_spec_mod, new_name = "field")

  if (.drop_optional) x <- drop_na_optional_spec_tables(x, table_spec, .data_case = names_case)

  new_quantityreport(x)
}

#' is_quantityreport_list
#'
#' \code{is_quantityreport_list()} check if the object is a list where all members are of class 'quantityreport'.
#'
#' @rdname quantityreport_class
#'
#' @export
is_quantityreport_list <- function(x) {
  all(vapply(x, is_quantityreport, logical(1)))
}


