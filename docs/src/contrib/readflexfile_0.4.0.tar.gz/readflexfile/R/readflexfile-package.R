## usethis namespace: start
#' @importFrom lifecycle deprecate_soft
#' @importFrom rlang := .data
## usethis namespace: end
NULL

# global data
#utils::globalVariables(c("flexfile_spec", "quantity_spec"))
