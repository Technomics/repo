library(testthat)
library(readflexfile)

test_check("readflexfile")
