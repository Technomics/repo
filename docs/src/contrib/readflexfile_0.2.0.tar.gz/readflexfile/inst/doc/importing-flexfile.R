## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(readflexfile)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
file <- system.file("extdata", "Sample_FlexFile_A.zip", package = "flexample")

list_ff <- read_ff(file)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
list_ff_id <- list_ff %>% 
  add_id_col(var = "doc_id")


## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
flexfile <- list_ff_id %>%
  flatten_ff()

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
folder <- system.file("extdata", package = "flexample")

list_ffs <- read_folder(folder, 
                        read_function = read_ff)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
list_ffs_id <- list_ffs %>%
  listindex_to_col(var = "doc_id")

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
list_ffs_stack <- list_ffs_id %>%
  stack_ff()

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
flexfiles <- list_ffs_stack %>%
   flatten_ff()

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = FALSE-----------------
#  quantity_data <- system.file("extdata", "Sample_Quantity_A.zip", package = "flexample")
#  
#  qdr <- read_ff(quantity_data) %>%
#    add_id_col(var = "doc_id") %>%
#    flatten_qdr()

