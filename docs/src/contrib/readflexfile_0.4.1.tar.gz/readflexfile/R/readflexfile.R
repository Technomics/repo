#' @description
#' To learn more about readflexfile, start with the vignettes:
#' `browseVignettes(package = "readflexfile")`
#' @keywords internal
"_PACKAGE"
