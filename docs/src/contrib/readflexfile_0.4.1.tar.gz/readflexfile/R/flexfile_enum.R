#' FlexFile enumeration tables
#'
#' A list containing nine data frames: \code{phaseormilestoneenum}, \code{contracttypeenum},
#' \code{appropriationtypeenum}, \code{reportcycleenum}, \code{nonrecurringorrecurringenum},
#' \code{standardcategoryenum}, \code{detailedstandardcategoryenum}, \code{allocationmethodtypeenum}, and
#' \code{costhourtagenum}.
#'
"flexfile_enum"
