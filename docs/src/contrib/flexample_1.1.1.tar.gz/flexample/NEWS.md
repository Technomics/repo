# flexample 1.1.1

* Minor fix to the example 'reportmetadata' table to read properly through parsers.

# flexample 1.1.0

* 'Sample_FlexFile_Aircraft.zip' added to replace 'Sample_FlexFile_B.zip'
* Examples pass through cPet.

# flexample 1.0.0

* Example flexfiles added. First released version!
