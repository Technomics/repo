## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(readflexfile)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
file <- system.file("extdata", "Sample_FlexFile_A.zip", package = "flexample")

raw_ff <- read_flexfile(file)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
flexfile <- raw_ff %>%
  flatten_data()

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
folder <- system.file("extdata", package = "flexample")

raw_ffs <- read_folder(folder, 
                        read_function = read_ff)

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
flexfiles <- raw_ffs %>%
   flatten_data()

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = TRUE------------------
suppressPackageStartupMessages(library(dplyr))

flexfiles_flat <- flexfiles %>% 
  bind_rows(.id = "doc_id")

## ----echo = TRUE, warning=FALSE, messages=FALSE, eval = FALSE-----------------
#  quantity_data <- system.file("extdata", "Sample_Quantity_A.zip", package = "flexample")
#  
#  qdr <- read_flexfile(quantity_data) %>%
#    flatten_data()

