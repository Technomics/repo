# readflexfile 0.2.0

* First public release of readflexfile! This package is available now on GitHub and
is licensed under the GPLv3.
* Run `browseVignettes("readflexfile")` to get started!


# readflexfile 0.1.0

* First external release of readflexfile!
